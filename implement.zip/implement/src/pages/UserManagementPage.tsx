import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";

import UsersListTable from "@/features/users/table/UserManagement";
import ActivityLogs from "@/features/users/table/ActivityLogs";
import { AddUserForm } from "@/features/users/form/add_user-form";
import ExportUsersButton from "@/features/users/button/ExportUsersButton";

export default function Page() {
  const [activeTab, setActiveTab] = useState("users");
  const [selectedUserIds, setSelectedUserIds] = useState<number[]>([]);
  const [users, setUsers] = useState<any[]>([]);

  const handleUserAdded = () => {
    // Handle user added logic
  };

  const handleUserSelection = (ids: number[]) => {
    setSelectedUserIds(ids);
  };

  const handleUsersData = (usersData: any[]) => {
    setUsers(usersData);
  };

  return (
    <div className="relative flex flex-col h-full w-full pt-2">
      {/* Conditionally render the button only when users tab is active */}
      {activeTab === "users" && (
        <div className="absolute flex right-6 top-2 gap-2 ">
          {/* Export button */}
          <ExportUsersButton selectedUserIds={selectedUserIds} users={users} />

          {/* Add user button */}
          <Button
            asChild
            className="w-fit transition duration-150 ease-in hover:scale-95 border-1 border-foreground"
            aria-label="Add new user"
          >
            <AddUserForm
              className="select-none cursor-pointer"
              onUserAdded={handleUserAdded}
            />
          </Button>
        </div>
      )}

      {/* Selectable tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList
          aria-label="User management sections"
          className="p-4 bg-muted-secondary gap-1 rounded-none"
        >
          <TabsTrigger
            value="users"
            className={`p-4 cursor-pointer transition duration-300 ease-in ${
              activeTab === "users" ? "text-foreground  " : ""
            }`}
            aria-selected={activeTab === "users"}
            aria-controls="users-content"
          >
            User Management
          </TabsTrigger>
          <TabsTrigger
            value="logs"
            className={`p-4 cursor-pointer transition duration-300 ease-in ${
              activeTab === "logs" ? "text-foreground " : ""
            }`}
            aria-selected={activeTab === "logs"}
            aria-controls="logs-content"
          >
            Activity Logs
          </TabsTrigger>
        </TabsList>

        <TabsContent
          value="users"
          id="users-content"
          role="tabpanel"
          aria-labelledby="users-tab"
          tabIndex={0}
        >
          <UsersListTable
            onSelectionChange={handleUserSelection}
            onUsersData={handleUsersData}
          />
        </TabsContent>

        <TabsContent
          value="logs"
          id="logs-content"
          role="tabpanel"
          aria-labelledby="logs-tab"
          tabIndex={0}
        >
          <ActivityLogs />
        </TabsContent>
      </Tabs>
    </div>
  );
}

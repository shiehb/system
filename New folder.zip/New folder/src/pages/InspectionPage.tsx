import { InspectionManagement } from "@/features/inspection";

export default function InspectionPage() {
  return <InspectionManagement />;
}

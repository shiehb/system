import ChiefDashboard from "./management/chief";

export default function ChiefDashboardPage() {
  return <ChiefDashboard />;
}

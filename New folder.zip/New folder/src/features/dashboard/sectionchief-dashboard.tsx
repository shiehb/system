export function SectionChiefDashboard() {
  return (
    <div>
      <h1>Section Chief Dashboard</h1>
    </div>
  );
}

export function InspectorDashboard() {
  return (
    <div>
      <h1>Inspector Dashboard</h1>
    </div>
  );
}

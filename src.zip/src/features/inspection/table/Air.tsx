// src/features/inspection/table/Air.tsx
import TableTemplate from "./TableTemplate";

export default function Air() {
  return <TableTemplate type="air" />;
}

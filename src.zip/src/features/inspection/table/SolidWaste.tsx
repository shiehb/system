// src/features/inspection/table/SolidWaste.tsx
import TableTemplate from "./TableTemplate";

export default function SolidWaste() {
  return <TableTemplate type="solidwaste" />;
}

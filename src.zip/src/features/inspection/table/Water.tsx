// src/features/inspection/table/Water.tsx
import TableTemplate from "./TableTemplate";

export default function Water() {
  return <TableTemplate type="water" />;
}

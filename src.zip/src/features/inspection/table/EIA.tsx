// src/features/inspection/table/EIA.tsx
import TableTemplate from "./TableTemplate";

export default function EIA() {
  return <TableTemplate type="eia" />;
}

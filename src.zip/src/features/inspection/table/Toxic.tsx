// src/features/inspection/table/Toxic.tsx
import TableTemplate from "./TableTemplate";

export default function Toxic() {
  return <TableTemplate type="toxic" />;
}

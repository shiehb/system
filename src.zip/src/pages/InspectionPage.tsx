import { InspectionTasking, InspectionForm } from "@/features/inspection";
export default function InspectionPage() {
  return (
    <div>
      <InspectionTasking />
      <InspectionForm />
    </div>
  );
}

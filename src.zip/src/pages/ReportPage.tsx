export default function ReportPage() {
  return (
    <div className="flex flex-1">
      <div className="flex flex-1 flex-col gap-4 p-4">Report Page</div>
    </div>
  );
}
